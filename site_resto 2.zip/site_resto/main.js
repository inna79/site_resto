// Scroll active

$(window)
    .scroll(function () {
        var scrollDistance = $(window).scrollTop();

        $("section").each(function (i) {
            if ($(this).position().top - 51 <= scrollDistance) {
                $('a[href*="#"]:not([href="#"]).active').removeClass("active");
                $("a").eq(i).addClass("active");
            }
        });
    })
    .scroll();

//Scroll to anchor
const check = $("#check")

$(function () {
    $('a[href*="#"]:not([href="#"])').click(function () {
        //        Если не использовать scroll active

        //        $('a').each(function () {
        //            $(this).removeClass('active');
        //        })
        //        $(this).addClass('active');
        check.prop("checked", false)
        console.log(check.attr("checked"))
        if (
            location.pathname.replace(/^\//, "") ===
                this.pathname.replace(/^\//, "") &&
            location.hostname === this.hostname
        ) {
            var target = $(this.hash);
            target = target.length
                ? target
                : $("[name=" + this.hash.slice(1) + "]");
            if (target.length) {
                $("html, body").animate(
                    {
                        scrollTop: target.offset().top - 50,
                    },
                    500
                );
                return false;
            }
        }
    });
});
